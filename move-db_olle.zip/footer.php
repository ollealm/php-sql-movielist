</main>
<footer class="footer mt-auto p-3 bg-dark">
  <div class="container text-center text-light">
    <span>Olle Alm 2020</span>
  </div>
</footer>
</body>

</html>