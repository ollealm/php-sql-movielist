# Movie DB – CRUD using PHP, SQL and Bootstrap

A move database where you can post, edit and delete movies. An introduction to PHP and SQL. Procedural PHP using prepared statements. Styled with Bootstrap 4.

## Core Tech

- PHP
- SQL
- Prepared Statements
- phpMyAdmin
- Bootstrap 4

## Screenshot

![Screenshot](screenshot.jpg)
